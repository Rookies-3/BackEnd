package com.store.rookiesoneteam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RookiesOneteamApplication {

    public static void main(String[] args) {
        SpringApplication.run(RookiesOneteamApplication.class, args);
    }

}
