package com.store.rookiesoneteam.domain.enums;

public enum SocialType {
    GOOGLE
}
